import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import ProductForm from './ProductForm';
import ProductList from './ProductList';
import UserManagement from './UserManagement';
import Dashboard from './Dashboard';
import HomePage from './HomePage';
import Login from './Login';
import './App.css';

const App = () => {
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);
  const [loggedInUser, setLoggedInUser] = useState(null);

  useEffect(() => {
    const storedProducts = JSON.parse(localStorage.getItem('products')) || [];
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
    const storedLoggedInUser = JSON.parse(localStorage.getItem('loggedInUser')) || null;

    setProducts(storedProducts);
    setUsers(storedUsers);
    setLoggedInUser(storedLoggedInUser);
  }, []);

  const addProduct = (product) => {
    const updatedProducts = [...products, product];
    setProducts(updatedProducts);
    localStorage.setItem('products', JSON.stringify(updatedProducts));
  };

  const updateProduct = (updatedProduct) => {
    const updatedProducts = products.map((product) =>
      product.id === updatedProduct.id ? updatedProduct : product
    );
    setProducts(updatedProducts);
    localStorage.setItem('products', JSON.stringify(updatedProducts));
  };

  const deleteProduct = (id) => {
    const updatedProducts = products.filter((product) => product.id !== id);
    setProducts(updatedProducts);
    localStorage.setItem('products', JSON.stringify(updatedProducts));
  };

  const addUser = (user) => {
    const updatedUsers = [...users, user];
    setUsers(updatedUsers);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
  };

  const handleLogin = (username, password) => {
    const user = users.find(
      (user) => user.username === username && user.password === password
    );
    if (user) {
      setLoggedInUser(user);
      localStorage.setItem('loggedInUser', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const handleRegister = (newUser) => {
    const userExists = users.some((user) => user.username === newUser.username);
    if (!userExists) {
      addUser(newUser);
      setLoggedInUser(newUser);
      localStorage.setItem('loggedInUser', JSON.stringify(newUser));
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    setLoggedInUser(null);
    localStorage.removeItem('loggedInUser');
  };

  return (
    <Router>
      <div className="app">
        <nav>
          
          {loggedInUser ? (
            <>
              <Link to="/dashboard">Dashboard</Link>
              <Link to="/products">Products</Link>
              <Link to="/users">Users</Link>
              <button onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <Link to="/login">Login</Link>
          )}
        </nav>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route
            path="/login"
            element={<Login onLogin={handleLogin} onRegister={handleRegister} loggedInUser={loggedInUser} />}
          />
          <Route
            path="/dashboard"
            element={loggedInUser ? <Dashboard products={products} /> : <Navigate to="/login" />}
          />
          <Route
            path="/products"
            element={
              loggedInUser ? (
                <>
                  <ProductForm addProduct={addProduct} />
                  <ProductList
                    products={products}
                    updateProduct={updateProduct}
                    deleteProduct={deleteProduct}
                  />
                </>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/users"
            element={
              loggedInUser ? (
                <UserManagement
                  users={users}
                  addUser={addUser}
                  updateUser={(user) => updateProduct(user)}
                  deleteUser={(id) => deleteProduct(id)}
                />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
