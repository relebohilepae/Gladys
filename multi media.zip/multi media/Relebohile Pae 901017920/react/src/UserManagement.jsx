import React, { useState, useEffect } from 'react';

const UserManagement = ({ users, addUser, loggedInUser }) => {
  const [user, setUser] = useState({ username: '', email: '' });
  const [isEditing, setIsEditing] = useState(false);
  const [currentUserId, setCurrentUserId] = useState(null);

  useEffect(() => {
    if (loggedInUser) {
      addUser(loggedInUser); // Add the logged-in user to the table
    }
  }, [loggedInUser, addUser]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEditing) {
      setUsers(users.map((u) => (u.id === currentUserId ? { ...user, id: currentUserId } : u)));
      setIsEditing(false);
      setCurrentUserId(null);
    } else {
      addUser({ ...user, id: Date.now() });
    }
    setUser({ username: '', email: '' });
  };

  const handleEdit = (userToEdit) => {
    setUser({ username: userToEdit.username, email: userToEdit.email });
    setIsEditing(true);
    setCurrentUserId(userToEdit.id);
  };

  const handleDelete = (userId) => {
    setUsers(users.filter((u) => u.id !== userId));
  };

  return (
    <div>
      <h2>User Management</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="username"
          placeholder="Username"
          value={user.username}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={user.email}
          onChange={handleChange}
          required
        />
        <button type="submit">{isEditing ? 'Update User' : 'Add User'}</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.username}</td>
              <td>{u.email}</td>
              <td>
                <button onClick={() => handleEdit(u)}>Edit</button>
                <button onClick={() => handleDelete(u.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserManagement;
