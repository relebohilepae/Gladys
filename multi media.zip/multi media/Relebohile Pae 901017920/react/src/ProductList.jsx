import React from 'react';
import './App.css';

const ProductList = ({ products, updateProduct, deleteProduct }) => {
  const handleUpdate = (id) => {
    const productToUpdate = products.find(product => product.id === id);
    const updatedQuantity = prompt("Update Quantity:", productToUpdate.quantity);
    if (updatedQuantity !== null) {
      updateProduct({ ...productToUpdate, quantity: updatedQuantity });
    }
  };

  return (
    <div>
      <h2>Product List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Category</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.name}</td>
              <td>{product.description}</td>
              <td>{product.category}</td>
              <td>${product.price}</td>
              <td>{product.quantity}</td>
              <td>
                <div className="action-buttons">
                  <button onClick={() => handleUpdate(product.id)}>Update</button>
                  <button onClick={() => deleteProduct(product.id)}>Delete</button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductList;
