import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const Dashboard = ({ products }) => {
  const totalStock = products.reduce((acc, product) => acc + parseInt(product.quantity || 0, 10), 0);

  
  const chartData = {
    labels: products.map(product => product.name),
    datasets: [
      {
        label: 'Quantity in Stock',
        data: products.map(product => parseInt(product.quantity || 0, 10)),
        backgroundColor: 'rgba(255, 99, 132, 0.6)', 
        borderColor: 'rgba(255, 99, 132, 1)',        
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: 'white',      
          font: {
            size: 14,           
          },
        },
      },
      title: {
        display: true,
        text: 'Stock Availability by Product',
        color: 'white',          
        font: {
          size: 18,              
        },
      },
      tooltip: {
        titleFont: { size: 16 },  
        bodyFont: { size: 14 },   
      },
    },
    scales: {
      x: {
        ticks: {
          color: 'white',       
          font: {
            size: 20,           
          },
        },
      },
      y: {
        ticks: {
          color: 'white',       
          font: {
            size: 20,           
          },
        },
      },
    },
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <p>Total Products in Stock: {totalStock}</p>
      
      
      <div style={{ width: '80%', margin: '0 auto' }}>
        <Bar data={chartData} options={chartOptions} />
      </div>
    </div>
  );
};

export default Dashboard;

